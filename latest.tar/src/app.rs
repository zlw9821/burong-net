use leptos::prelude::*;
use leptos_meta::*;
use leptos_router::{
    StaticSegment,
    components::{Route, Router, Routes},
};

#[component]
pub fn App() -> impl IntoView {
    provide_meta_context();

    view! {
        // <Stylesheet id="leptos" href="assets/main.css"/>
        <Link rel="shortcut icon" type_="image/ico" href="/favicon.ico"/>
        <Router>
            <Routes fallback=|| "Page not found.">
                <Route path=StaticSegment("") view=Home/>
                <Route path=StaticSegment("/b") view=Banner/>
            </Routes>
        </Router>
    }
}

#[component]
fn Home() -> impl IntoView {
    let (value, set_value) = signal(0);

    // thanks to https://tailwindcomponents.com/component/blue-buttons-example for the showcase layout
    view! {
        <Title text="Leptos + Tailwindcss"/>
        <main>
            <div class="bg-gradient-to-tl from-blue-800 to-blue-500 text-white font-mono flex flex-col min-h-screen">
                <div class="flex flex-row-reverse flex-wrap m-auto">
                    <button on:click=move |_| set_value.update(|value| *value += 1) class="rounded px-3 py-2 m-1 border-b-4 border-l-2 shadow-lg bg-blue-700 border-blue-800 text-white">
                        "+"
                    </button>
                    <button class="rounded px-3 py-2 m-1 border-b-4 border-l-2 shadow-lg bg-blue-800 border-blue-900 text-white">
                        {value}
                    </button>
                    <button
                        on:click=move |_| set_value.update(|value| *value -= 1)
                        class="rounded px-3 py-2 m-1 border-b-4 border-l-2 shadow-lg bg-blue-700 border-blue-800 text-white"
                        class:invisible=move || {value.get() < 1}
                    >
                        "-"
                    </button>
                </div>
                <p class="text-center text-black-500">
                    This is a simple counter app built with Leptos and styled with Tailwind CSS.
                </p>
            </div>
        </main>
    }
}

#[component]
fn Banner() -> impl IntoView {
    view! {
        <div class="m-12 space-y-6">
            <div class="bg-green-100 border-t border-b border-green-500 text-green-700 px-4 py-3" role="alert">
                <p class="font-bold">Informational message</p>
                <p class="text-sm">Some additional text to explain said message.</p>
            </div>

            <div class="bg-blue-100 border-t border-b border-blue-500 text-blue-700 px-4 py-3" role="alert">
                <p class="font-bold">Informational message</p>
                <p class="text-sm">Some additional text to explain said message.</p>
            </div>

            <div class="bg-amber-100 border-t border-b border-amber-500 text-amber-700 px-4 py-3" role="alert">
                <p class="font-bold">Informational message</p>
                <p class="text-sm">Some additional text to explain said message.</p>
            </div>

            <div class="bg-red-100 border-t border-b border-red-500 text-red-700 px-4 py-3" role="alert">
                <p class="font-bold">Informational message</p>
                <p class="text-sm">Some additional text to explain said message.</p>
            </div>

            <div class="bg-purple-100 border-t border-b border-purple-500 text-purple-700 px-4 py-3" role="alert">
                <p class="font-bold">Informational message</p>
                <p class="text-sm">Some additional text to explain said message.</p>
            </div>
            <div class="bg-gray-100 border-t border-b border-gray-500 text-gray-700 px-4 py-3" role="alert">
                <p class="font-bold">Informational message</p>
                <p class="text-sm">Some additional text to explain said message.</p>
            </div>
        </div>
    }
}
